package com.campo.appmenu.model

data class Estudiante(
    val nombres: String,
    val apellidos: String,
    val edad: Int,
    val fotoRes: Int
)
