package com.campo.appmenu.data

import com.campo.appmenu.R
import com.campo.appmenu.model.Estudiante

object DatosEstudiantes {

    val lista = mutableListOf(
        Estudiante("Juan", "Pérez", 20, R.drawable.estudiante01),
        Estudiante("María", "López", 22, R.drawable.estudiante02),
        Estudiante("Carlos", "Sánchez", 19, R.drawable.estudiante03),
        Estudiante("Ana", "García", 21, R.drawable.estudiante04),
        Estudiante("Luis", "Ramírez", 23, R.drawable.estudiante05),
        Estudiante("Sofía", "Martínez", 20, R.drawable.estudiante06),
        Estudiante("Pedro", "Fernández", 24, R.drawable.estudiante07)
    )
}
